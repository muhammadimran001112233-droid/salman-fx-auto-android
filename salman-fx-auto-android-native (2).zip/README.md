# SALMAN FX AUTO - Native Android Studio Project (Kotlin + Jetpack Compose)

This is the complete, official native Android Studio project for **SALMAN FX AUTO**, specially architected and optimized for the **Infinix Smart 8** and modern Android smartphones.

---

## Technical Specifications
- **Target OS**: Android 7.0 (API 24) to Android 14 (API 34+)
- **Device Optimization**: Infinix Smart 8 (Unisoc T606, 3GB/4GB RAM, 90Hz Smooth Display)
- **Framework**: Kotlin 2.0.0 + Jetpack Compose (Material3)
- **Orientation**: Portrait locked by default
- **Architecture**: MVVM with Kotlin Coroutines & StateFlow
- **Performance**: Zero-stutter 60fps/90fps Canvas-rendered Candlestick Chart
- **Trading Mode**: STRICTLY DEMO / PAPER TRADING (No real broker API, zero risk, no scraping or clicking on real accounts)

---

## How to Build the APK (.apk) for Infinix Smart 8

### Option 1: Using Android Studio (Recommended)
1. Unzip `salman-fx-auto-android-native.zip` onto your PC.
2. Launch **Android Studio** (Hedgehog, Iguana, Koala, or Ladybug).
3. Select **Open** and select the unzipped `android` folder.
4. Let Gradle sync automatically (takes 1-2 minutes).
5. From the top menu, click:
   **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**
6. Once compiled, Android Studio will display a popup:
   *`APK(s) generated successfully for 1 module: Locate`*
7. Click **Locate**. Your APK is located at:
   `app/build/outputs/apk/debug/app-debug.apk`
8. Transfer `app-debug.apk` to your **Infinix Smart 8** via USB cable, WhatsApp, or Google Drive, and tap **Install**!

### Option 2: Command Line (Gradle)
```bash
cd android
./gradlew assembleDebug
```
The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

### Option 3: Install directly to Infinix Smart 8 via USB (ADB)
Enable Developer Options and USB Debugging on your Infinix Smart 8:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## Features Implemented in Native Kotlin & Compose
- **Touch-Draggable Floating Board**: Move the floating bot anywhere on screen with smooth touch drag and boundary clamping.
- **Auto Bot Engine**: Multi-indicator consensus (EMA 9/21/50, RSI 14, Bollinger Bands, MACD) with RUNNING / STOP toggle.
- **Fast Scalping Expiries**: 5s, 10s, 15s, 1m with instant visual feedback.
- **Real-time Candlestick Canvas**: Ultra-smooth price action rendering matching Quotex terminal charts.
- **Safe & Independent**: Never interferes with real money or real broker accounts. 100% compliant demo simulator.
