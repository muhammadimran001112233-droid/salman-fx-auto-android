@rem
@rem Gradle wrapper script for Windows
@rem
gradle %*
