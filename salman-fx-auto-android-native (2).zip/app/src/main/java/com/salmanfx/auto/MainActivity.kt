package com.salmanfx.auto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.salmanfx.auto.model.TradeDirection
import com.salmanfx.auto.model.TradeStatus
import com.salmanfx.auto.ui.components.*
import com.salmanfx.auto.ui.theme.*
import com.salmanfx.auto.viewmodel.TradingViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SalmanFxTheme {
                val viewModel: TradingViewModel = viewModel()
                MainAppScreen(viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: TradingViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val account by viewModel.account.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isAutoTrading by viewModel.isAutoTrading.collectAsState()
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val currentPrice by viewModel.currentPrice.collectAsState()
    val candles by viewModel.candles.collectAsState()
    val signal by viewModel.signal.collectAsState()
    val trades by viewModel.trades.collectAsState()
    val assets by viewModel.assets.collectAsState()
    val selectedExpiry by viewModel.selectedExpiry.collectAsState()
    val isMinimized by viewModel.isFloatingMinimized.collectAsState()
    val floatingOffset by viewModel.floatingOffset.collectAsState()

    var showFloatingBoard by remember { mutableStateOf(true) }

    // Android back button handling
    BackHandler(enabled = currentTab != "HOME") {
        viewModel.selectTab("HOME")
    }

    Scaffold(
        topBar = {
            AppHeader(
                account = account,
                isAutoTrading = isAutoTrading,
                soundEnabled = settings.soundEnabled,
                showFloatingBoard = showFloatingBoard,
                onToggleAutoTrading = { viewModel.toggleAutoTrade() },
                onEmergencyStop = { viewModel.emergencyStop() },
                onToggleSound = { viewModel.updateSettings(settings.copy(soundEnabled = !settings.soundEnabled)) },
                onToggleFloatingBoard = { showFloatingBoard = !showFloatingBoard }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentTab = currentTab,
                onSelectTab = { viewModel.selectTab(it) }
            )
        },
        containerColor = DarkBg
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentTab) {
                "HOME", "LIVE_CHART" -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Asset selector row
                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceDark)
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(assets) { asset ->
                                val isSelected = asset.symbol == selectedAsset.symbol
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSelected) EmeraldPrimary.copy(alpha = 0.2f) else CardDark)
                                        .border(
                                            0.5.dp,
                                            if (isSelected) EmeraldPrimary else Color(0xFF1E293B),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .clickable { viewModel.selectAsset(asset) }
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        asset.symbol,
                                        color = if (isSelected) EmeraldLight else TextSecondary,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        // Candlestick Chart Area
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            CandlestickChart(
                                candles = candles,
                                currentPrice = currentPrice
                            )
                        }

                        // Manual Trade Action Controls Bar (CALL / PUT)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CardDark)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // CALL Button
                            Button(
                                onClick = {
                                    viewModel.executeTrade(
                                        TradeDirection.CALL,
                                        settings.defaultStake,
                                        selectedExpiry,
                                        currentPrice
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = DarkBg, modifier = Modifier.size(16.dp))
                                    Text("CALL (HIGHER)", color = DarkBg, fontSize = 10.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                }
                            }

                            // PUT Button
                            Button(
                                onClick = {
                                    viewModel.executeTrade(
                                        TradeDirection.PUT,
                                        settings.defaultStake,
                                        selectedExpiry,
                                        currentPrice
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RoseAccent),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Text("PUT (LOWER)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                "AUTO_BOT" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("SALMAN FX AUTOMATED BOT ENGINE", color = EmeraldLight, fontSize = 11.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CardDark)
                                .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("STATUS: ${if (isAutoTrading) "ACTIVE (RUNNING)" else "STANDBY (STOPPED)"}", color = if (isAutoTrading) EmeraldLight else RoseAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("CURRENT SIGNAL: ${signal.action.name} (${signal.confidence}%)", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text("REASON: ${signal.reasoning}", color = TextSecondary, fontSize = 8.5.sp)
                                Text("TIMEFRAME: ${selectedExpiry}s", color = TextSecondary, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)

                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = { viewModel.toggleAutoTrade() },
                                    modifier = Modifier.fillMaxWidth().height(42.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = if (isAutoTrading) RoseAccent else EmeraldPrimary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(if (isAutoTrading) "STOP AUTO BOT" else "START AUTO BOT", color = if (isAutoTrading) Color.White else DarkBg, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                "TRADES" -> {
                    val pendingTrades = trades.filter { it.status == TradeStatus.PENDING }
                    Column(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                        Text("ACTIVE LIVE TRADES (${pendingTrades.size})", color = EmeraldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        if (pendingTrades.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No open trades right now.\nPlace a trade or turn on Auto Bot.", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                        } else {
                            pendingTrades.forEach { trade ->
                                TradeItemRow(trade)
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                }

                "HISTORY" -> {
                    HistoryScreen(trades = trades, account = account)
                }

                "SETTINGS" -> {
                    SettingsScreen(
                        settings = settings,
                        onUpdateSettings = { viewModel.updateSettings(it) },
                        onResetDemoAccount = { viewModel.resetDemoAccount() }
                    )
                }
            }

            // Floating Touch-Draggable Board Overlay
            if (showFloatingBoard) {
                CompactFloatingBoard(
                    asset = selectedAsset,
                    signal = signal,
                    isRunning = isAutoTrading,
                    selectedExpiry = selectedExpiry,
                    isMinimized = isMinimized,
                    floatingOffset = floatingOffset,
                    onToggleMinimize = { viewModel.toggleFloatingMinimized() },
                    onToggleRunning = { viewModel.toggleAutoTrade() },
                    onSelectExpiry = { viewModel.selectExpiry(it) },
                    onPositionChanged = { viewModel.updateFloatingPosition(it) }
                )
            }
        }
    }
}
