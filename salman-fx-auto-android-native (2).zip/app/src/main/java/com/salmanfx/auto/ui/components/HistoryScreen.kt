package com.salmanfx.auto.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salmanfx.auto.model.AccountState
import com.salmanfx.auto.model.Trade
import com.salmanfx.auto.model.TradeDirection
import com.salmanfx.auto.model.TradeStatus
import com.salmanfx.auto.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(
    trades: List<Trade>,
    account: AccountState,
    modifier: Modifier = Modifier
) {
    val completedTrades = trades.filter { it.status != TradeStatus.PENDING }.reversed()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Stats Overview Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CardDark)
                .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TOTAL TRADES", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text("${account.totalTrades}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("WIN RATE", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text("${String.format("%.1f", account.winRate)}%", color = EmeraldLight, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NET PROFIT", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    val isPos = account.todayProfit >= 0
                    Text(
                        "${if (isPos) "+" else ""}$${String.format("%.2f", account.todayProfit)}",
                        color = if (isPos) EmeraldLight else RoseAccent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Text(
            "COMPLETED TRADES LOG",
            color = TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        if (completedTrades.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No completed trades yet.\nEnable AUTO BOT or execute manual signals to log results.",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(completedTrades) { trade ->
                    TradeItemRow(trade)
                }
            }
        }
    }
}

@Composable
fun TradeItemRow(trade: Trade) {
    val isWin = trade.status == TradeStatus.WIN
    val statusColor = when (trade.status) {
        TradeStatus.WIN -> EmeraldPrimary
        TradeStatus.LOSS -> RoseAccent
        else -> AmberAccent
    }
    val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceDark)
            .border(0.5.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (trade.direction == TradeDirection.CALL) EmeraldPrimary.copy(alpha = 0.2f) else RoseAccent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (trade.direction == TradeDirection.CALL) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = if (trade.direction == TradeDirection.CALL) EmeraldLight else RoseAccent,
                        modifier = Modifier.size(14.dp)
                    )
                }

                Column {
                    Text(trade.asset, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(
                        "${trade.direction.name} • ${trade.durationSec}s • ${timeFormatter.format(Date(trade.openTime))}",
                        color = TextSecondary,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${if (isWin) "+" else ""}$${String.format("%.2f", trade.profit)}",
                    color = statusColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    trade.status.name,
                    color = statusColor,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
