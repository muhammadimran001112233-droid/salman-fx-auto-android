package com.salmanfx.auto.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salmanfx.auto.model.MarketAsset
import com.salmanfx.auto.model.SignalAction
import com.salmanfx.auto.model.SignalResult
import com.salmanfx.auto.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun CompactFloatingBoard(
    modifier: Modifier = Modifier,
    asset: MarketAsset,
    signal: SignalResult,
    isRunning: Boolean,
    selectedExpiry: Int,
    isMinimized: Boolean,
    floatingOffset: Offset,
    onToggleMinimize: () -> Unit,
    onToggleRunning: () -> Unit,
    onSelectExpiry: (Int) -> Unit,
    onPositionChanged: (Offset) -> Unit
) {
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current

    val screenWidthPx = with(density) { configuration.screenWidthDp.dp.toPx() }
    val screenHeightPx = with(density) { configuration.screenHeightDp.dp.toPx() }

    // Dimensions
    val boardWidthDp = 180.dp
    val boardHeightDp = 270.dp
    val boardWidthPx = with(density) { boardWidthDp.toPx() }
    val boardHeightPx = with(density) { boardHeightDp.toPx() }

    // Clamp coordinates safely
    val clampedX = floatingOffset.x.coerceIn(8f, (screenWidthPx - boardWidthPx - 8f).coerceAtLeast(8f))
    val clampedY = floatingOffset.y.coerceIn(70f, (screenHeightPx - boardHeightPx - 80f).coerceAtLeast(70f))

    val rotationTransition = rememberInfiniteTransition(label = "rotation")
    val rotation by rotationTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radarRotate"
    )

    if (isMinimized) {
        // Minimized floating pill
        Box(
            modifier = Modifier
                .offset { IntOffset(clampedX.roundToInt(), clampedY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onPositionChanged(
                            Offset(
                                (clampedX + dragAmount.x).coerceIn(8f, screenWidthPx - 160f),
                                (clampedY + dragAmount.y).coerceIn(70f, screenHeightPx - 120f)
                            )
                        )
                    }
                }
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF090E1C), Color(0xFF111827))))
                .border(1.dp, EmeraldPrimary.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                .clickable { onToggleMinimize() }
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .rotate(rotation)
                        .background(EmeraldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("S", fontSize = 8.sp, fontWeight = FontWeight.Black, color = DarkBg)
                }
                Text(
                    "SALMAN FX AUTO",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(if (isRunning) EmeraldPrimary else RoseAccent, CircleShape)
                )
            }
        }
    } else {
        // Expanded Compact Board
        Box(
            modifier = Modifier
                .offset { IntOffset(clampedX.roundToInt(), clampedY.roundToInt()) }
                .width(boardWidthDp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val newX = (clampedX + dragAmount.x).coerceIn(8f, screenWidthPx - boardWidthPx - 8f)
                        val newY = (clampedY + dragAmount.y).coerceIn(70f, screenHeightPx - boardHeightPx - 80f)
                        onPositionChanged(Offset(newX, newY))
                    }
                }
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xE6050811))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .rotate(if (isRunning) rotation else 0f)
                                .background(EmeraldPrimary, RoundedCornerShape(3.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("S", fontSize = 8.sp, fontWeight = FontWeight.Black, color = DarkBg)
                        }
                        Column {
                            Text(
                                "SALMAN FX",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                lineHeight = 10.sp
                            )
                            Text(
                                "AUTO BOT",
                                color = EmeraldLight,
                                fontSize = 7.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 8.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF1E293B))
                                .clickable { onToggleMinimize() }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("—", color = TextSecondary, fontSize = 9.sp)
                        }
                    }
                }

                // Asset badge
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0F172A))
                        .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            asset.symbol,
                            color = Color.White,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            "${(asset.payout * 100).toInt()}%",
                            color = EmeraldLight,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                // Expiry Selector Pills (5s, 10s, 15s, 1m)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    val expiries = listOf(5 to "5s", 10 to "10s", 15 to "15s", 60 to "1m")
                    expiries.forEach { (sec, label) ->
                        val isSelected = selectedExpiry == sec
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) EmeraldPrimary else Color(0xFF0B1120))
                                .border(
                                    0.5.dp,
                                    if (isSelected) EmeraldLight else Color(0xFF1E293B),
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { onSelectExpiry(sec) }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                label,
                                color = if (isSelected) DarkBg else TextSecondary,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Signal Banner
                val actionColor = when (signal.action) {
                    SignalAction.CALL -> EmeraldPrimary
                    SignalAction.PUT -> RoseAccent
                    SignalAction.WAIT -> AmberAccent
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(actionColor.copy(alpha = 0.15f))
                        .border(1.dp, actionColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .padding(vertical = 4.dp, horizontal = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Icon(
                                imageVector = when (signal.action) {
                                    SignalAction.CALL -> Icons.Default.ArrowUpward
                                    SignalAction.PUT -> Icons.Default.ArrowDownward
                                    SignalAction.WAIT -> Icons.Default.HourglassEmpty
                                },
                                contentDescription = null,
                                tint = actionColor,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                signal.action.name,
                                color = actionColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            "${signal.confidence}% CONF",
                            color = Color.White,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Telemetry summary chip
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF0A0F1D))
                        .padding(horizontal = 5.dp, vertical = 3.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("RSI(14): ${String.format("%.1f", signal.indicators.rsi)}", color = TextSecondary, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
                            Text("EMA: 9/21/50", color = TextSecondary, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                // RUNNING / STOP RUNNING Button
                Button(
                    onClick = onToggleRunning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRunning) RoseAccent else EmeraldPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (isRunning) Color.White else DarkBg,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            if (isRunning) "⏹ STOP RUNNING" else "▶ RUNNING",
                            color = if (isRunning) Color.White else DarkBg,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
