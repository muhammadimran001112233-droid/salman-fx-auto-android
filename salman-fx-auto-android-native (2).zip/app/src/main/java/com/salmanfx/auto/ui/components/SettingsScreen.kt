package com.salmanfx.auto.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salmanfx.auto.model.UserSettings
import com.salmanfx.auto.ui.theme.*

@Composable
fun SettingsScreen(
    settings: UserSettings,
    onUpdateSettings: (UserSettings) -> Unit,
    onResetDemoAccount: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(10.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Disclaimer Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E1402))
                .border(0.5.dp, AmberAccent.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(8.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = AmberAccent, modifier = Modifier.size(16.dp))
                Column {
                    Text("PAPER TRADING ONLY", color = AmberAccent, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(
                        "SALMAN FX AUTO is a simulated binary options paper-trading tool. It does not connect to real broker accounts, click on broker screens, or use real capital.",
                        color = TextSecondary,
                        fontSize = 8.sp,
                        lineHeight = 11.sp
                    )
                }
            }
        }

        // Section: Risk & Money Management
        Text("RISK & STAKE MANAGEMENT", color = EmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(CardDark)
                .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Stake selector
                Text("DEFAULT STAKE (USD)", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                val stakes = listOf(5.0, 10.0, 25.0, 50.0, 100.0)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    stakes.forEach { st ->
                        val isSel = settings.defaultStake == st
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) EmeraldPrimary else SurfaceDark)
                                .clickable { onUpdateSettings(settings.copy(defaultStake = st)) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "$${st.toInt()}",
                                color = if (isSel) DarkBg else TextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Min Confidence Slider
                Text("MIN BOT SIGNAL CONFIDENCE: ${settings.minConfidence}%", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Slider(
                    value = settings.minConfidence.toFloat(),
                    onValueChange = { onUpdateSettings(settings.copy(minConfidence = it.toInt())) },
                    valueRange = 65f..95f,
                    steps = 6,
                    colors = SliderDefaults.colors(
                        thumbColor = EmeraldLight,
                        activeTrackColor = EmeraldPrimary,
                        inactiveTrackColor = Color(0xFF1E293B)
                    )
                )

                // Sound Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("AUDIO & SIGNAL CHIMES", color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Switch(
                        checked = settings.soundEnabled,
                        onCheckedChange = { onUpdateSettings(settings.copy(soundEnabled = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = EmeraldLight,
                            checkedTrackColor = EmeraldDark
                        )
                    )
                }
            }
        }

        // Section: Reset Demo Account
        Button(
            onClick = onResetDemoAccount,
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = EmeraldLight, modifier = Modifier.size(16.dp))
                Text("RESET DEMO BALANCE ($10,000)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        // Infinix Smart 8 device info badge
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceDark)
                .padding(8.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("HARDWARE COMPATIBILITY", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("Optimized for Infinix Smart 8 (Unisoc T606 / 3GB-4GB RAM / 90Hz)", color = EmeraldLight, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                Text("Touch-draggable overlays, 60fps canvas engine, and battery saver mode enabled.", color = TextMuted, fontSize = 7.5.sp)
            }
        }
    }
}
