package com.salmanfx.auto.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salmanfx.auto.model.AccountState
import com.salmanfx.auto.ui.theme.*

@Composable
fun AppHeader(
    account: AccountState,
    isAutoTrading: Boolean,
    soundEnabled: Boolean,
    showFloatingBoard: Boolean,
    onToggleAutoTrading: () -> Unit,
    onEmergencyStop: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleFloatingBoard: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CardDark,
        border = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(EmeraldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("S", fontSize = 12.sp, fontWeight = FontWeight.Black, color = DarkBg)
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                "SALMAN FX",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                "AUTO",
                                color = EmeraldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(AmberAccent.copy(alpha = 0.2f))
                                    .border(0.5.dp, AmberAccent.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 3.dp, vertical = 1.dp)
                            ) {
                                Text("DEMO", color = AmberAccent, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Balance Quick Card
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        "DEMO BAL",
                        color = TextSecondary,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        "$${String.format("%,.2f", account.balance)}",
                        color = EmeraldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Quick Action Controls
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Floating board toggle
                    IconButton(
                        onClick = onToggleFloatingBoard,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (showFloatingBoard) EmeraldPrimary.copy(alpha = 0.2f) else SurfaceDark)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Toggle Board",
                            tint = if (showFloatingBoard) EmeraldLight else TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // Emergency Stop
                    IconButton(
                        onClick = onEmergencyStop,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(RoseAccent)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Emergency Stop",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
