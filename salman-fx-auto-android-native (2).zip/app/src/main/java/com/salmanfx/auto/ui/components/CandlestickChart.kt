package com.salmanfx.auto.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.salmanfx.auto.model.Candle
import com.salmanfx.auto.ui.theme.DarkBg
import com.salmanfx.auto.ui.theme.EmeraldPrimary
import com.salmanfx.auto.ui.theme.RoseAccent

@Composable
fun CandlestickChart(
    modifier: Modifier = Modifier,
    candles: List<Candle>,
    currentPrice: Double
) {
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        if (candles.isEmpty()) return@Canvas

        val visibleCandles = if (candles.size > 35) candles.takeLast(35) else candles
        val minPrice = visibleCandles.minOfOrNull { it.low } ?: currentPrice
        val maxPrice = visibleCandles.maxOfOrNull { it.high } ?: currentPrice
        val priceRange = (maxPrice - minPrice).coerceAtLeast(0.0001)

        val width = size.width
        val height = size.height
        val candleCount = visibleCandles.size
        val candleSpacing = width / (candleCount + 1)
        val candleBodyWidth = (candleSpacing * 0.65f).coerceAtLeast(4f)

        // Draw horizontal grid lines
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = (height / gridLines) * i
            drawLine(
                color = Color(0xFF1E293B).copy(alpha = 0.5f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
        }

        // Draw candles
        visibleCandles.forEachIndexed { index, candle ->
            val x = (index + 1) * candleSpacing
            val isBullish = candle.close >= candle.open
            val candleColor = if (isBullish) EmeraldPrimary else RoseAccent

            val highY = height - (((candle.high - minPrice) / priceRange) * (height * 0.85f) + (height * 0.08f)).toFloat()
            val lowY = height - (((candle.low - minPrice) / priceRange) * (height * 0.85f) + (height * 0.08f)).toFloat()
            val openY = height - (((candle.open - minPrice) / priceRange) * (height * 0.85f) + (height * 0.08f)).toFloat()
            val closeY = height - (((candle.close - minPrice) / priceRange) * (height * 0.85f) + (height * 0.08f)).toFloat()

            // Draw wick
            drawLine(
                color = candleColor,
                start = Offset(x, highY),
                end = Offset(x, lowY),
                strokeWidth = 1.5f
            )

            // Draw body
            val topY = minOf(openY, closeY)
            val bodyHeight = maxOf(kotlin.math.abs(openY - closeY), 2f)

            drawRect(
                color = candleColor,
                topLeft = Offset(x - (candleBodyWidth / 2), topY),
                size = Size(candleBodyWidth, bodyHeight)
            )
        }

        // Draw Current Price Line
        val currentY = height - (((currentPrice - minPrice) / priceRange) * (height * 0.85f) + (height * 0.08f)).toFloat()
        drawLine(
            color = EmeraldPrimary,
            start = Offset(0f, currentY),
            end = Offset(width, currentY),
            strokeWidth = 1.5f
        )
    }
}
