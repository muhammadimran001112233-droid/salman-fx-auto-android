package com.salmanfx.auto.engine

import com.salmanfx.auto.model.Candle
import com.salmanfx.auto.model.MarketAsset
import kotlin.random.Random

class MarketDataService {

    val availableAssets = listOf(
        MarketAsset("EUR/USD (OTC)", "Euro / US Dollar OTC", 0.89, "OTC Currencies", 1.08450),
        MarketAsset("GBP/USD (OTC)", "British Pound / USD OTC", 0.88, "OTC Currencies", 1.29320),
        MarketAsset("USD/JPY (OTC)", "US Dollar / Japanese Yen OTC", 0.87, "OTC Currencies", 154.620),
        MarketAsset("AUD/CAD (OTC)", "Australian / Canadian Dollar", 0.85, "OTC Currencies", 0.89840),
        MarketAsset("BTC/USD", "Bitcoin / USD", 0.82, "Crypto", 64250.00),
        MarketAsset("GOLD (OTC)", "Gold vs US Dollar OTC", 0.90, "Commodities", 2514.80)
    )

    private val candleMap = mutableMapOf<String, MutableList<Candle>>()
    private val random = Random(System.currentTimeMillis())

    init {
        availableAssets.forEach { asset ->
            candleMap[asset.symbol] = generateInitialCandles(asset.currentPrice)
        }
    }

    private fun generateInitialCandles(basePrice: Double): MutableList<Candle> {
        val list = mutableListOf<Candle>()
        var current = basePrice
        val now = System.currentTimeMillis()
        val candlePeriodMs = 1000L // 1-second candles for scalping

        for (i in 60 downTo 0) {
            val delta = (random.nextDouble() - 0.495) * (basePrice * 0.00035)
            val open = current
            val close = current + delta
            val high = maxOf(open, close) + random.nextDouble() * (basePrice * 0.0001)
            val low = minOf(open, close) - random.nextDouble() * (basePrice * 0.0001)

            list.add(Candle(
                timestamp = now - (i * candlePeriodMs),
                open = open,
                high = high,
                low = low,
                close = close
            ))
            current = close
        }
        return list
    }

    fun tick(symbol: String): Pair<Double, List<Candle>> {
        val candles = candleMap.getOrPut(symbol) { generateInitialCandles(1.08450) }
        val lastCandle = candles.last()

        val volatility = lastCandle.close * 0.00025
        val delta = (random.nextDouble() - 0.49) * volatility
        val newPrice = (lastCandle.close + delta).coerceAtLeast(0.0001)

        val updatedLast = lastCandle.copy(
            high = maxOf(lastCandle.high, newPrice),
            low = minOf(lastCandle.low, newPrice),
            close = newPrice
        )
        candles[candles.size - 1] = updatedLast

        // Roll into new candle periodically
        if (System.currentTimeMillis() - lastCandle.timestamp >= 1000L) {
            candles.add(Candle(
                timestamp = System.currentTimeMillis(),
                open = newPrice,
                high = newPrice,
                low = newPrice,
                close = newPrice
            ))
            if (candles.size > 120) {
                candles.removeAt(0)
            }
        }

        return Pair(newPrice, candles.toList())
    }

    fun getCandles(symbol: String): List<Candle> {
        return candleMap[symbol]?.toList() ?: emptyList()
    }
}
