package com.salmanfx.auto.viewmodel

import android.app.Application
import android.content.Context
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.salmanfx.auto.engine.ExecutionEngine
import com.salmanfx.auto.engine.MarketDataService
import com.salmanfx.auto.engine.SignalEngine
import com.salmanfx.auto.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("salman_fx_prefs", Context.MODE_PRIVATE)
    private val marketService = MarketDataService()
    private val executionEngine = ExecutionEngine()

    private val _assets = MutableStateFlow(marketService.availableAssets)
    val assets: StateFlow<List<MarketAsset>> = _assets.asStateFlow()

    private val _selectedAsset = MutableStateFlow(marketService.availableAssets[0])
    val selectedAsset: StateFlow<MarketAsset> = _selectedAsset.asStateFlow()

    private val _currentPrice = MutableStateFlow(selectedAsset.value.currentPrice)
    val currentPrice: StateFlow<Double> = _currentPrice.asStateFlow()

    private val _candles = MutableStateFlow<List<Candle>>(emptyList())
    val candles: StateFlow<List<Candle>> = _candles.asStateFlow()

    private val _signal = MutableStateFlow(SignalResult())
    val signal: StateFlow<SignalResult> = _signal.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _account = MutableStateFlow(
        AccountState(
            balance = prefs.getFloat("account_balance", 10000.0f).toDouble(),
            todayProfit = prefs.getFloat("today_profit", 0.0f).toDouble()
        )
    )
    val account: StateFlow<AccountState> = _account.asStateFlow()

    private val _settings = MutableStateFlow(
        UserSettings(
            defaultStake = prefs.getFloat("default_stake", 10.0f).toDouble(),
            defaultExpirySec = prefs.getInt("default_expiry", 15),
            soundEnabled = prefs.getBoolean("sound_enabled", true),
            autoTradeEnabled = false,
            minConfidence = prefs.getInt("min_confidence", 78)
        )
    )
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private val _isAutoTrading = MutableStateFlow(false)
    val isAutoTrading: StateFlow<Boolean> = _isAutoTrading.asStateFlow()

    private val _selectedExpiry = MutableStateFlow(_settings.value.defaultExpirySec)
    val selectedExpiry: StateFlow<Int> = _selectedExpiry.asStateFlow()

    private val _isFloatingMinimized = MutableStateFlow(false)
    val isFloatingMinimized: StateFlow<Boolean> = _isFloatingMinimized.asStateFlow()

    private val _floatingOffset = MutableStateFlow(
        Offset(
            prefs.getFloat("float_pos_x", 16f),
            prefs.getFloat("float_pos_y", 72f)
        )
    )
    val floatingOffset: StateFlow<Offset> = _floatingOffset.asStateFlow()

    private val _currentTab = MutableStateFlow("HOME")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    init {
        startMarketSimulation()
    }

    private fun startMarketSimulation() {
        viewModelScope.launch {
            while (true) {
                val symbol = _selectedAsset.value.symbol
                val (newPrice, updatedCandles) = marketService.tick(symbol)
                _currentPrice.value = newPrice
                _candles.value = updatedCandles

                // Evaluate signal
                val newSignal = SignalEngine.evaluate(updatedCandles, _selectedExpiry.value)
                _signal.value = newSignal

                // Check pending trades
                val updatedTrades = executionEngine.updatePendingTrades(newPrice, symbol) { finishedTrade, won ->
                    handleTradeResult(finishedTrade, won)
                }
                _trades.value = updatedTrades

                // Auto trade execution if enabled
                if (_isAutoTrading.value) {
                    checkAutoTradeTrigger(newSignal, newPrice)
                }

                delay(1000L) // 1 second update loop
            }
        }
    }

    private fun checkAutoTradeTrigger(sig: SignalResult, price: Double) {
        if (sig.confidence < _settings.value.minConfidence) return

        val hasPendingOnAsset = _trades.value.any { it.asset == _selectedAsset.value.symbol && it.status == TradeStatus.PENDING }
        if (hasPendingOnAsset) return

        val direction = when (sig.action) {
            SignalAction.CALL -> TradeDirection.CALL
            SignalAction.PUT -> TradeDirection.PUT
            SignalAction.WAIT -> return
        }

        val stake = executionEngine.getNextStake(
            _settings.value.defaultStake,
            _settings.value.martingaleMultiplier,
            _settings.value.maxConsecutiveLosses
        )

        if (_account.value.balance >= stake) {
            executeTrade(direction, stake, _selectedExpiry.value, price)
        }
    }

    fun executeTrade(direction: TradeDirection, stake: Double, durationSec: Int, currentPrice: Double) {
        if (_account.value.balance < stake) return

        val trade = executionEngine.openTrade(
            asset = _selectedAsset.value,
            direction = direction,
            stake = stake,
            durationSec = durationSec,
            entryPrice = currentPrice
        )

        _account.value = _account.value.copy(
            balance = _account.value.balance - stake
        )
        _trades.value = executionEngine.getTrades()
    }

    private fun handleTradeResult(trade: Trade, won: Boolean) {
        val currentAcc = _account.value
        val returnAmount = if (won) trade.stake + trade.profit else 0.0
        val newBalance = currentAcc.balance + returnAmount
        val newTodayProfit = currentAcc.todayProfit + trade.profit
        val newWins = currentAcc.wins + (if (won) 1 else 0)
        val newLosses = currentAcc.losses + (if (!won) 1 else 0)

        _account.value = currentAcc.copy(
            balance = newBalance,
            todayProfit = newTodayProfit,
            totalTrades = currentAcc.totalTrades + 1,
            wins = newWins,
            losses = newLosses
        )

        prefs.edit()
            .putFloat("account_balance", newBalance.toFloat())
            .putFloat("today_profit", newTodayProfit.toFloat())
            .apply()

        // Check Take Profit or Stop Loss
        if (newTodayProfit >= _settings.value.takeProfitLimit || newTodayProfit <= -_settings.value.stopLossLimit) {
            _isAutoTrading.value = false
        }
    }

    fun toggleAutoTrade() {
        _isAutoTrading.value = !_isAutoTrading.value
    }

    fun emergencyStop() {
        _isAutoTrading.value = false
    }

    fun selectAsset(asset: MarketAsset) {
        _selectedAsset.value = asset
        _candles.value = marketService.getCandles(asset.symbol)
    }

    fun selectExpiry(durationSec: Int) {
        _selectedExpiry.value = durationSec
    }

    fun toggleFloatingMinimized() {
        _isFloatingMinimized.value = !_isFloatingMinimized.value
    }

    fun updateFloatingPosition(offset: Offset) {
        _floatingOffset.value = offset
        prefs.edit()
            .putFloat("float_pos_x", offset.x)
            .putFloat("float_pos_y", offset.y)
            .apply()
    }

    fun selectTab(tab: String) {
        _currentTab.value = tab
    }

    fun resetDemoAccount() {
        executionEngine.reset()
        _trades.value = emptyList()
        _account.value = AccountState(balance = 10000.0, initialBalance = 10000.0, todayProfit = 0.0)
        prefs.edit()
            .putFloat("account_balance", 10000.0f)
            .putFloat("today_profit", 0.0f)
            .apply()
    }

    fun updateSettings(newSettings: UserSettings) {
        _settings.value = newSettings
        prefs.edit()
            .putFloat("default_stake", newSettings.defaultStake.toFloat())
            .putInt("default_expiry", newSettings.defaultExpirySec)
            .putBoolean("sound_enabled", newSettings.soundEnabled)
            .putInt("min_confidence", newSettings.minConfidence)
            .apply()
    }
}
