package com.salmanfx.auto.engine

import com.salmanfx.auto.model.*
import java.util.UUID

class ExecutionEngine {

    private val trades = mutableListOf<Trade>()
    private var consecutiveLosses = 0

    fun openTrade(
        asset: MarketAsset,
        direction: TradeDirection,
        stake: Double,
        durationSec: Int,
        entryPrice: Double
    ): Trade {
        val trade = Trade(
            id = UUID.randomUUID().toString().take(8),
            asset = asset.symbol,
            direction = direction,
            entryPrice = entryPrice,
            stake = stake,
            payoutMultiplier = 1.0 + asset.payout,
            durationSec = durationSec,
            openTime = System.currentTimeMillis()
        )
        trades.add(trade)
        return trade
    }

    fun updatePendingTrades(currentPrice: Double, symbol: String, onTradeFinished: (Trade, Boolean) -> Unit): List<Trade> {
        val now = System.currentTimeMillis()
        val finishedTrades = mutableListOf<Trade>()

        trades.filter { it.status == TradeStatus.PENDING && it.asset == symbol }.forEach { trade ->
            val elapsedMs = now - trade.openTime
            if (elapsedMs >= trade.durationSec * 1000L) {
                trade.closeTime = now
                trade.exitPrice = currentPrice

                val won = when (trade.direction) {
                    TradeDirection.CALL -> trade.exitPrice > trade.entryPrice
                    TradeDirection.PUT -> trade.exitPrice < trade.entryPrice
                }

                if (trade.exitPrice == trade.entryPrice) {
                    trade.status = TradeStatus.TIE
                    trade.profit = 0.0
                } else if (won) {
                    trade.status = TradeStatus.WIN
                    trade.profit = trade.stake * (trade.payoutMultiplier - 1.0)
                    consecutiveLosses = 0
                } else {
                    trade.status = TradeStatus.LOSS
                    trade.profit = -trade.stake
                    consecutiveLosses++
                }

                finishedTrades.add(trade)
                onTradeFinished(trade, won)
            }
        }

        return trades.toList()
    }

    fun getNextStake(baseStake: Double, multiplier: Double, maxLosses: Int): Double {
        return if (consecutiveLosses > 0 && consecutiveLosses <= maxLosses) {
            baseStake * Math.pow(multiplier, consecutiveLosses.toDouble())
        } else {
            baseStake
        }
    }

    fun getTrades(): List<Trade> = trades.toList()

    fun reset() {
        trades.clear()
        consecutiveLosses = 0
    }
}
