package com.salmanfx.auto.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF050811)
val SurfaceDark = Color(0xFF0A0E17)
val CardDark = Color(0xFF111827)
val CardBorder = Color(0xFF1F2937)

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldLight = Color(0xFF34D399)
val EmeraldDark = Color(0xFF047857)

val RoseAccent = Color(0xFFF43F5E)
val RoseDark = Color(0xFFBE123C)

val AmberAccent = Color(0xFFF59E0B)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
