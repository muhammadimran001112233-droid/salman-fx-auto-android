package com.salmanfx.auto.model

enum class TradeDirection {
    CALL, PUT
}

enum class TradeStatus {
    PENDING, WIN, LOSS, TIE
}

enum class SignalAction {
    CALL, PUT, WAIT
}

data class MarketAsset(
    val symbol: String,
    val name: String,
    val payout: Double,
    val category: String,
    val currentPrice: Double,
    val spread: Double = 0.00002
)

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 100.0
)

data class IndicatorValues(
    val rsi: Double = 50.0,
    val ema9: Double = 0.0,
    val ema21: Double = 0.0,
    val ema50: Double = 0.0,
    val macd: Double = 0.0,
    val macdSignal: Double = 0.0,
    val macdHist: Double = 0.0,
    val bbUpper: Double = 0.0,
    val bbLower: Double = 0.0,
    val bbMiddle: Double = 0.0,
    val stochasticK: Double = 50.0,
    val stochasticD: Double = 50.0
)

data class SignalResult(
    val action: SignalAction = SignalAction.WAIT,
    val confidence: Int = 0,
    val reasoning: String = "Scanning market telemetry...",
    val durationSec: Int = 60,
    val timestamp: Long = System.currentTimeMillis(),
    val indicators: IndicatorValues = IndicatorValues()
)

data class Trade(
    val id: String,
    val asset: String,
    val direction: TradeDirection,
    val entryPrice: Double,
    var exitPrice: Double = 0.0,
    val stake: Double,
    val payoutMultiplier: Double = 1.85,
    var profit: Double = 0.0,
    val durationSec: Int,
    val openTime: Long,
    var closeTime: Long = 0L,
    var status: TradeStatus = TradeStatus.PENDING
)

data class AccountState(
    val balance: Double = 10000.0,
    val initialBalance: Double = 10000.0,
    val todayProfit: Double = 0.0,
    val totalTrades: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0
) {
    val winRate: Double
        get() = if (totalTrades > 0) (wins.toDouble() / totalTrades) * 100.0 else 0.0
}

data class UserSettings(
    val defaultStake: Double = 10.0,
    val defaultExpirySec: Int = 15,
    val soundEnabled: Boolean = true,
    val autoTradeEnabled: Boolean = false,
    val minConfidence: Int = 78,
    val martingaleMultiplier: Double = 2.0,
    val maxConsecutiveLosses: Int = 3,
    val takeProfitLimit: Double = 500.0,
    val stopLossLimit: Double = 250.0
)
