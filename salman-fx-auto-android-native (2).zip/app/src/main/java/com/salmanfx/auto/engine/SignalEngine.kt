package com.salmanfx.auto.engine

import com.salmanfx.auto.model.Candle
import com.salmanfx.auto.model.SignalAction
import com.salmanfx.auto.model.SignalResult
import kotlin.math.abs

object SignalEngine {

    fun evaluate(candles: List<Candle>, durationSec: Int): SignalResult {
        if (candles.size < 25) {
            return SignalResult(
                action = SignalAction.WAIT,
                confidence = 45,
                reasoning = "Accumulating live market telemetry...",
                durationSec = durationSec
            )
        }

        val indicators = TechnicalIndicators.calculateIndicators(candles)
        val currentPrice = candles.last().close

        var callScore = 0
        var putScore = 0
        val reasons = mutableListOf<String>()

        // 1. EMA Trend alignment
        if (indicators.ema9 > indicators.ema21 && indicators.ema21 > indicators.ema50) {
            callScore += 30
            reasons.add("EMA Stack Bullish (9 > 21 > 50)")
        } else if (indicators.ema9 < indicators.ema21 && indicators.ema21 < indicators.ema50) {
            putScore += 30
            reasons.add("EMA Stack Bearish (9 < 21 < 50)")
        }

        // 2. RSI Signals
        if (indicators.rsi < 32.0) {
            callScore += 35
            reasons.add("RSI Oversold (${String.format("%.1f", indicators.rsi)})")
        } else if (indicators.rsi > 68.0) {
            putScore += 35
            reasons.add("RSI Overbought (${String.format("%.1f", indicators.rsi)})")
        } else if (indicators.rsi in 52.0..62.0) {
            callScore += 15
        } else if (indicators.rsi in 38.0..48.0) {
            putScore += 15
        }

        // 3. Bollinger Bands Mean Reversion
        if (currentPrice <= indicators.bbLower && indicators.bbLower > 0.0) {
            callScore += 25
            reasons.add("Lower Bollinger Band Bounce")
        } else if (currentPrice >= indicators.bbUpper && indicators.bbUpper > 0.0) {
            putScore += 25
            reasons.add("Upper Bollinger Band Rejection")
        }

        // 4. MACD Momentum
        if (indicators.macdHist > 0.00005) {
            callScore += 15
            reasons.add("MACD Histogram Positive")
        } else if (indicators.macdHist < -0.00005) {
            putScore += 15
            reasons.add("MACD Histogram Negative")
        }

        // 5. Stochastic
        if (indicators.stochasticK < 20.0) {
            callScore += 15
        } else if (indicators.stochasticK > 80.0) {
            putScore += 15
        }

        val netDiff = callScore - putScore
        val action: SignalAction
        val confidence: Int
        val primaryReason: String

        when {
            netDiff >= 40 -> {
                action = SignalAction.CALL
                confidence = (72 + (netDiff * 0.3).toInt()).coerceIn(75, 96)
                primaryReason = if (reasons.isNotEmpty()) reasons.joinToString(" • ") else "High Bullish Momentum"
            }
            netDiff <= -40 -> {
                action = SignalAction.PUT
                confidence = (72 + (abs(netDiff) * 0.3).toInt()).coerceIn(75, 96)
                primaryReason = if (reasons.isNotEmpty()) reasons.joinToString(" • ") else "High Bearish Momentum"
            }
            else -> {
                action = SignalAction.WAIT
                confidence = 50 + (abs(netDiff) / 2)
                primaryReason = "Consolidation / Range-bound. Awaiting breakout."
            }
        }

        return SignalResult(
            action = action,
            confidence = confidence,
            reasoning = primaryReason,
            durationSec = durationSec,
            timestamp = System.currentTimeMillis(),
            indicators = indicators
        )
    }
}
