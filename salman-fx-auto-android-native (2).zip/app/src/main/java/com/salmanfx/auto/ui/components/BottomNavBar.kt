package com.salmanfx.auto.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salmanfx.auto.ui.theme.*

data class NavItem(
    val id: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun BottomNavBar(
    currentTab: String,
    onSelectTab: (String) -> Unit
) {
    val items = listOf(
        NavItem("HOME", "Home", Icons.Default.Dashboard),
        NavItem("AUTO_BOT", "Bot", Icons.Default.SmartToy),
        NavItem("LIVE_CHART", "Chart", Icons.Default.ShowChart),
        NavItem("TRADES", "Trades", Icons.Default.SwapHoriz),
        NavItem("HISTORY", "History", Icons.Default.History),
        NavItem("SETTINGS", "Settings", Icons.Default.Settings)
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CardDark
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp, horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            items.forEach { item ->
                val isSelected = currentTab == item.id
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) EmeraldPrimary.copy(alpha = 0.15f) else Color.Transparent)
                        .clickable { onSelectTab(item.id) }
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (isSelected) EmeraldLight else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        item.label,
                        color = if (isSelected) EmeraldLight else TextMuted,
                        fontSize = 8.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
