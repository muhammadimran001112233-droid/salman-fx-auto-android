package com.salmanfx.auto.engine

import com.salmanfx.auto.model.Candle
import com.salmanfx.auto.model.IndicatorValues
import kotlin.math.sqrt

object TechnicalIndicators {

    fun calculateEma(prices: List<Double>, period: Int): Double {
        if (prices.isEmpty()) return 0.0
        if (prices.size < period) return prices.average()

        val k = 2.0 / (period + 1)
        var ema = prices.subList(0, period).average()
        for (i in period until prices.size) {
            ema = (prices[i] * k) + (ema * (1.0 - k))
        }
        return ema
    }

    fun calculateRsi(prices: List<Double>, period: Int = 14): Double {
        if (prices.size <= period) return 50.0

        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = prices[i] - prices[i - 1]
            if (diff >= 0) gains += diff else losses += -diff
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until prices.size) {
            val diff = prices[i] - prices[i - 1]
            val gain = if (diff > 0) diff else 0.0
            val loss = if (diff < 0) -diff else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun calculateBollingerBands(prices: List<Double>, period: Int = 20, multiplier: Double = 2.0): Triple<Double, Double, Double> {
        if (prices.isEmpty()) return Triple(0.0, 0.0, 0.0)
        val slice = if (prices.size > period) prices.takeLast(period) else prices
        val sma = slice.average()

        val variance = slice.sumOf { (it - sma) * (it - sma) } / slice.size
        val stdDev = sqrt(variance)

        val upper = sma + (multiplier * stdDev)
        val lower = sma - (multiplier * stdDev)
        return Triple(upper, sma, lower)
    }

    fun calculateIndicators(candles: List<Candle>): IndicatorValues {
        if (candles.size < 20) return IndicatorValues()
        val closes = candles.map { it.close }

        val ema9 = calculateEma(closes, 9)
        val ema21 = calculateEma(closes, 21)
        val ema50 = calculateEma(closes, 50)
        val rsi = calculateRsi(closes, 14)

        val ema12 = calculateEma(closes, 12)
        val ema26 = calculateEma(closes, 26)
        val macdLine = ema12 - ema26
        val macdSignal = macdLine * 0.85 // simplified smoothing
        val macdHist = macdLine - macdSignal

        val (bbUpper, bbMiddle, bbLower) = calculateBollingerBands(closes, 20)

        // Stochastic
        val last14 = candles.takeLast(14)
        val highestHigh = last14.maxOfOrNull { it.high } ?: closes.last()
        val lowestLow = last14.minOfOrNull { it.low } ?: closes.last()
        val currentClose = closes.last()

        val range = highestHigh - lowestLow
        val stochK = if (range != 0.0) ((currentClose - lowestLow) / range) * 100.0 else 50.0

        return IndicatorValues(
            rsi = rsi.coerceIn(0.0, 100.0),
            ema9 = ema9,
            ema21 = ema21,
            ema50 = ema50,
            macd = macdLine,
            macdSignal = macdSignal,
            macdHist = macdHist,
            bbUpper = bbUpper,
            bbLower = bbLower,
            bbMiddle = bbMiddle,
            stochasticK = stochK.coerceIn(0.0, 100.0),
            stochasticD = stochK.coerceIn(0.0, 100.0)
        )
    }
}
