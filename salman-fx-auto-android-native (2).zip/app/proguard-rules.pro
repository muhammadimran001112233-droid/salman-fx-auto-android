# Proguard rules for SALMAN FX AUTO
-dontobfuscate
-keepattributes *Annotation*
